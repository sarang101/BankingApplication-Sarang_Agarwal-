package com.fis.bankingapplication.exceptions;

public class AccountNotFound extends Exception {

	public AccountNotFound(String message) {
		super(message);
	}

}

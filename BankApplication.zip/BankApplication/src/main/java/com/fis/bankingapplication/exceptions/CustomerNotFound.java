package com.fis.bankingapplication.exceptions;

public class CustomerNotFound extends Exception {

	public CustomerNotFound(String message) {
		super(message);
	}

}

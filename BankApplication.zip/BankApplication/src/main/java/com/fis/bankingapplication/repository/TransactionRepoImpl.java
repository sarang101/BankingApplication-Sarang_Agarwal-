package com.fis.bankingapplication.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.fis.bankingapplication.model.Transaction;

@Repository
public class TransactionRepoImpl implements TransactionRepo{

	//This is the class which implements the abstract methods.
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public String addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		entityManager.persist(transaction);
		return "Transaction Added Successfully";	
	}

	@Override
	public List<Transaction> getTransactions(long fromAccount) {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> query = entityManager.createQuery("select t from Transaction t where t.fromAccount=?1", Transaction.class);
		query.setParameter(1,fromAccount);
		return query.getResultList();
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> query = entityManager.createQuery("select t from Transaction t", Transaction.class);
		return query.getResultList();
	}

}

package com.fis.bankingapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapplication.exceptions.CustomerNotFound;
import com.fis.bankingapplication.model.Customer;
import com.fis.bankingapplication.service.CustomerService;

//This is the object of type Customer which we input.
//{
//"cusId":117,
//"cusName":"Sarang",
//"cusEmail":sarang@gmail.com,
//"cusPassword":"123",
//"cusMob":"123",
//"cusAadhar":"123",
//"cusPrmAdd":"Agra",
//"cusResiAdd":"Agra",
//"cusDob":"2001-17-04"
//}

//This is the customer controller class having routes of the Restful APIs.
@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	CustomerService service;

	@PostMapping("/addCustomer") // http://localhost:8080/customers/addCustomer
	public String saveCustomer(@RequestBody Customer customer) {
		return service.addCustomer(customer);
	}

	@PutMapping("/updateCustomer") // http://localhost:8080/customers/updateCustomer
	public String updateCustomer(@RequestBody Customer customer) {
		return service.updateCustomer(customer);
	}

	@GetMapping("/getCustomer/{cid}") // http://localhost:8080/customers/getCustomer/888
	public Customer getCustomer(@PathVariable("cid") int cusId) throws CustomerNotFound {
		return service.getCustomer(cusId);
	}
	
	@DeleteMapping("/deleteCustomer/{cid}") // http://localhost:8080/customers/deleteCustomer/888
	public String deleteCustomer(@PathVariable("cid") int cusId) throws CustomerNotFound {
		try{
			return service.deleteCustomer(cusId);
		} 
		catch (CustomerNotFound cnf) {
			return "Customer Not Found";
			
		}
	}
	@GetMapping("/getAllCustomers") // http://localhost:8080/customers/getAllCustomers
	public List<Customer> getCustomers() {
		return service.getAllCustomer();
	}
}

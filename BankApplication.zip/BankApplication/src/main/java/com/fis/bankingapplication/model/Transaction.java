package com.fis.bankingapplication.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


//This is the account entity class which has transaction_info table fields & getter & setter functions.
//Also there are parameterized & default constructor
@Entity
@Table(name="transaction_info")
public class Transaction {
	
	@Id
	@Column(name="tid")
	private int transId;
	private String transType;
	private long fromAccount;
	private long toAccount;
	private String dateOfTransaction;
	private double amount;
	private String status;
	
	
	public Transaction(int transId, String transType, int fromAccount, long toAccount, String dateOfTransaction,
			double amount, String status) {
		super();
		this.transId = transId;
		this.transType = transType;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.dateOfTransaction = dateOfTransaction;
		this.amount = amount;
		this.status = status;
	}
	
	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}


	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public long getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}
	public long getToAccount() {
		return toAccount;
	}
	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}
	public String getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
//	public Double getTransTime() {
//		return transTime;
//	}
//	public void setTransTime(Double transTime) {
//		this.transTime = transTime;
//	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return String.format(
				"Transaction [transId=%s, transType=%s, fromAccount=%s, toAccount=%s, dateOfTransaction=%s, amount=%s, status=%s]",
				transId, transType, fromAccount, toAccount, dateOfTransaction, amount, status);
	}
	
	
	
}


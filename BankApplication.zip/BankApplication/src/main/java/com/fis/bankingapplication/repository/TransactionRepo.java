package com.fis.bankingapplication.repository;

import java.util.List;
import com.fis.bankingapplication.model.Transaction;

public interface TransactionRepo {
	
	//This is the interface class having  abstract methods.
	String addTransaction(Transaction transaction);
	public List<Transaction> getTransactions(long fromAccount);
	public List<Transaction> getAllTransactions();
	
}



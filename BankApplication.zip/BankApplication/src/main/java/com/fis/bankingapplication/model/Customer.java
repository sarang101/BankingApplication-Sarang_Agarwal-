package com.fis.bankingapplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//Registration
//This is the account entity class which has customers_info table fields & getter & setter functions.
//Also there are parameterized & default constructor
@Entity
@Table(name="customers_info")
public class Customer {
	
	@Id
	@Column(name="cid")
	private int cusId;
	private String cusName;
	private String cusEmail;
	private String cusPassword;
	private int cusMob;
    private long cusAadhar;
	private String cusPrmAadd;
	private String cusResiAdd;
	private String cusDob;
	
	
	public Customer(int cusId, String cusName, String cusEmail, String cusPassword, int cusMob, long cusAadhar,
			String cusPrmAadd, String cusResiAdd, String cusDob) {
		super();
		this.cusId = cusId;
		this.cusName = cusName;
		this.cusEmail = cusEmail;
		this.cusPassword = cusPassword;
		this.cusMob = cusMob;
		this.cusAadhar = cusAadhar;
		this.cusPrmAadd = cusPrmAadd;
		this.cusResiAdd = cusResiAdd;
		this.cusDob = cusDob;
	}
	
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}


	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusEmail() {
		return cusEmail;
	}
	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}
	public String getCusPassword() {
		return cusPassword;
	}
	public void setCusPassword(String cusPassword) {
		this.cusPassword = cusPassword;
	}
	public int getCusMob() {
		return cusMob;
	}
	public void setCusMob(int cusMob) {
		this.cusMob = cusMob;
	}
	public long getCusAadhar() {
		return cusAadhar;
	}
	public void setCusAadhar(long cusAadhar) {
		this.cusAadhar = cusAadhar;
	}
	public String getCusPrmAadd() {
		return cusPrmAadd;
	}
	public void setCusPrmAadd(String cusPrmAadd) {
		this.cusPrmAadd = cusPrmAadd;
	}
	public String getCusResiAdd() {
		return cusResiAdd;
	}
	public void setCusResiAdd(String cusResiAdd) {
		this.cusResiAdd = cusResiAdd;
	}
	public String getCusDob() {
		return cusDob;
	}
	public void setCusDob(String cusDob) {
		this.cusDob = cusDob;
	}
	
	@Override
	public String toString() {
		return String.format(
				"Customer [cusId=%s, cusName=%s, cusEmail=%s, cusPassword=%s, cusMob=%s, cusAadhar=%s, cusPrmAadd=%s, cusResiAdd=%s, cusDob=%s]",
				cusId, cusName, cusEmail, cusPassword, cusMob, cusAadhar, cusPrmAadd, cusResiAdd, cusDob);
	}
	
	
	

}

package com.fis.bankingapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapplication.model.Transaction;
import com.fis.bankingapplication.repository.TransactionRepo;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{
	
	//This is the transaction service implementation class which implements the abstract methods.
	@Autowired
	TransactionRepo repo;

	@Override
	public String addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		return repo.addTransaction(transaction);
	}

	@Override
	public List<Transaction> getTransactions(long fromAccount) {
		// TODO Auto-generated method stub
		return repo.getTransactions(fromAccount);
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return repo.getAllTransactions();
	}
}

package com.fis.bankingapplication.service;

import java.util.List;

import com.fis.bankingapplication.exceptions.CustomerNotFound;
import com.fis.bankingapplication.model.Customer;

public interface CustomerService {
	
	//This is the customer service interface class which is the service layer of the project.
	//It has the abstract methods 
	 String addCustomer(Customer customer);
	 String updateCustomer(Customer customer);
	 public Customer getCustomer(int cusId) throws CustomerNotFound;
	 public String deleteCustomer(int cusId) throws CustomerNotFound;
	 public List<Customer> getAllCustomer();
	 //void changePasswordUsingMobile(int mobile, String password);
	
}

package com.fis.bankingapplication.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankingapplication.exceptions.CustomerNotFound;
import com.fis.bankingapplication.model.Customer;

@Repository
public class CustomerRepoImpl implements CustomerRepo{
	
	//This is the class which implements the abstract methods.
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public String addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		entityManager.persist(customer);
		return "Customer Added Successfully";
	}

	@Override
	public String updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		entityManager.merge(customer);
		return "Customer updated Successfully";
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound{
		if(entityManager.find(Customer.class, custId) != null) {
			return entityManager.find(Customer.class, custId);
	}else {
		throw new CustomerNotFound("Invalid Customer Id");
	}
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {
		if(entityManager.find(Customer.class, custId) != null) {
			entityManager.remove(getCustomer(custId));
			return "Customer Removed Successfully";
	}else {
		throw new CustomerNotFound("Invalid Customer Id");
	}
		
	}
	
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query = entityManager.createQuery("select c from Customer c", Customer.class);
		return query.getResultList();
	}

	

	
	
}

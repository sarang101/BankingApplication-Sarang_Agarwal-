package com.fis.bankingapplication.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankingapplication.exceptions.AccountNotFound;
import com.fis.bankingapplication.model.Account;
import com.fis.bankingapplication.model.Transaction;

@Repository
public class AccountRepoImpl implements AccountRepo{
	
	//This is the class which implements the abstract methods.
	@PersistenceContext
	EntityManager entityManager;
	
	static int transId=1;
	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		entityManager.persist(account);
		return "Account created Successfully";
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		entityManager.merge(account);
		return "Account Updated Successfully";
	}

	@Override
	public String deleteAccount(long accNum) throws AccountNotFound {
		// TODO Auto-generated method stub
		if(entityManager.find(Account.class, accNum) != null){
			entityManager.remove(getAccount(accNum));
			return "Account Removed Successfully";
	} else {
		throw new AccountNotFound("Invalid Account Number");
	}
	}

	@Override
	public Account getAccount(long accNum) throws AccountNotFound{
		// TODO Auto-generated method stub
		if(entityManager.find(Account.class,accNum)!=null) {
			return entityManager.find(Account.class, accNum);}
		else {
			throw new AccountNotFound("Invalid Account Number");
		}
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		TypedQuery<Account> query = entityManager.createQuery("select a from Account a", Account.class);
		return query.getResultList();
	}

	@Override
	public String depositIntoBalance(long accNum, double depositAmount) {
		// TODO Auto-generated method stub
		//TypedQuery<Account> query = entityManager.createQuery("Update Account a set a.balance=a.balance+?1 where accNum=?2 ", Account.class);
		//query.setParameter(1, depositAmount);
		//query.setParameter(2, accNum);
		//query.executeUpdate();
		Account account1= entityManager.find(Account.class, accNum);
		double currBalance=account1.getBalance();
		double updatedBalance=currBalance+depositAmount;
		account1.setBalance(updatedBalance);
		entityManager.merge(account1);
		Transaction transaction1=new Transaction();
		transaction1.setTransId(transId);
		transId++;
		transaction1.setAmount(depositAmount);
		transaction1.setStatus("Success");
		transaction1.setToAccount(0);
		transaction1.setFromAccount(accNum);
		transaction1.setTransType("Deposit");
		entityManager.merge(transaction1);
		return "Deposited Successfully";
	}

	@Override
	public String withdrawFromBalance(long accNum, double withdrawAmount) {
		// TODO Auto-generated method stub
//		TypedQuery<Account> query = entityManager.createQuery("update Account set balance=balance-?1 where accNum=?2", Account.class);
//		query.setParameter(1, withdrawAmount);
//		query.setParameter(2, accNum);
		Account account2= entityManager.find(Account.class, accNum);
		double currBalance=account2.getBalance();
		Transaction transaction1=new Transaction();
		transaction1.setTransId(transId);
		transId++;
		transaction1.setAmount(withdrawAmount);
		transaction1.setToAccount(0);
		transaction1.setFromAccount(accNum);
		transaction1.setTransType("Withdraw");
		if(currBalance-withdrawAmount<0) {
			transaction1.setStatus("Failed");
			entityManager.merge(transaction1);
			return "Insufficient Balance";
			}
		else {
		double updatedBalance=currBalance-withdrawAmount;
		account2.setBalance(updatedBalance);
		entityManager.merge(account2);
		transaction1.setStatus("Success");
		entityManager.merge(transaction1);
		return "Withdrawn Successfully";}
	}

	@Override
	public String FundTransfer(long fromAccount, long toAccount, double amount, String transType) {
		// TODO Auto-generated method stub
		Account account1= entityManager.find(Account.class, fromAccount);
		Account account2= entityManager.find(Account.class, toAccount);
		double account1Balance=account1.getBalance();
		Transaction transaction1=new Transaction();
		transaction1.setTransId(transId);
		transId++;
		transaction1.setAmount(amount);
		transaction1.setToAccount(toAccount);
		transaction1.setFromAccount(fromAccount);
		transaction1.setTransType("FundTransfer:" + transType);
		if(account1Balance-amount<0) {
			transaction1.setStatus("Failed");
			entityManager.merge(transaction1);
			return "Insufficient Balance";
		}
		account1.setBalance(account1Balance-amount);
		account2.setBalance(account2.getBalance()+amount);
		transaction1.setStatus("Success");
		entityManager.merge(transaction1);
		return "Fund Transfered Successfully";
	}

}

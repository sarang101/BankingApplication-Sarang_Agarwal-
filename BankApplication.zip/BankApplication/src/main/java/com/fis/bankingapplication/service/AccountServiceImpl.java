package com.fis.bankingapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapplication.exceptions.AccountNotFound;
import com.fis.bankingapplication.exceptions.NotEnoughBalance;
import com.fis.bankingapplication.model.Account;
import com.fis.bankingapplication.repository.AccountRepo;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	
	//This is the account service implementation class which implements the abstract methods.
	@Autowired
	AccountRepo repo;
	
	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		return repo.createAccount(account);
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		return repo.updateAccount(account);
	}

	@Override
	public String deleteAccount(long accNum) throws AccountNotFound{
		// TODO Auto-generated method stub
		return repo.deleteAccount(accNum);
	}

	@Override
	public Account getAccount(long accNum) throws AccountNotFound{
		// TODO Auto-generated method stub
		return repo.getAccount(accNum);
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return repo.getAllAccounts();
	}

	@Override
	public String depositIntoBalance(long accNum, double depositAmount){
		// TODO Auto-generated method stub
		return repo.depositIntoBalance(accNum, depositAmount);
	}

	@Override
	public String withdrawFromBalance(long accNum, double withdrawAmount) throws NotEnoughBalance{
		// TODO Auto-generated method stub
		return repo.withdrawFromBalance(accNum, withdrawAmount);
	}

	@Override
	public String FundTransfer(long fromAccount, long toAccount, double amount, String transType) {
		// TODO Auto-generated method stub
		return repo.FundTransfer(fromAccount, toAccount, amount, transType);
	}

}
